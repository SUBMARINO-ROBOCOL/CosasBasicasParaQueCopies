class Rosbag2Transport {
    // not yet implemented
}